# Linux Shell Project

**Description:**  
A minimal Unix shell implementation written in C.

This project was built to explore core operating system concepts including process creation, program execution, signal handling, pipes, and basic job control.

---

## Features

- Tokenizing and Parsing comands to create Jobs
- Execute external programs using `fork()` and `execve()`
- Support for foreground and background execution (`&`)
- Basic pipeline support (`|`)
- Manual `PATH` resolution

---

## Limitations

This is a learning-focused implementation and does not aim to fully replicate a POSIX-compliant shell. Advanced job control features such as process groups, terminal ownership management, and built-in commands like `fg`/`bg`/`cd` are not implemented.

## Purpose

Built as part of an Operating Systems project to gain hands-on experience with low-level Unix system calls and process control.