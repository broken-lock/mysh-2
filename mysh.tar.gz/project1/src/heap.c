
#include "heap.h"


static unsigned char heap[HEAP_SIZE];
static size_t offset = 0;

/**
 * my_alloc
 *
 * allocates memory in the main heap of a given size.
 *
 * @param size  amount of bytes to allocate
 *
 * @returns A pointer to the allocated space. Null when no space is available.
 *
 */
void* my_alloc(size_t size) {
    void* blockp = NULL;
    size = ALIGN8(size);

    if (size == 0)
        return NULL;
    else if (size + offset > HEAP_SIZE)
        return NULL;
    else {
        blockp = &heap[offset];
        offset += size;
        return blockp;
    }
}

/**
 * freeAll
 *
 * Sets all memory to 0 and resets the pointer and counter of the mainHeap
 */
void freeAll() {
    for (int i = 0; i < HEAP_SIZE; i++) {
        heap[i] = 0;
    }
    offset = 0;
}

