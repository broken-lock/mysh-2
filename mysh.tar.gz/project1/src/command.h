
#ifndef COMMAND_H
#define COMMAND_H



#define ARG_MAX 32
#define MAX_ARG_LEN 128

#define BACKGROUND_FLAG 1
#define EXIT_FLAG 2

#include <sys/types.h>
#include "global.h"

typedef struct Command {
    const char* argv[ARG_MAX + 1];
    unsigned int argc;
    pid_t pid;
    unsigned char flags;
}Command;




#endif