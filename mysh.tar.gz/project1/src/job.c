#include "job.h"
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include "utility.h"
#include <errno.h>
#include "heap.h"
#include "tokenizer.h"
#include <signal.h>


#define FILE_MODE 0644  //octal permissions for file creation

#define EXIT_CMD_NOT_FOUND 127
#define EXIT_PERMISSION_DENIED 126

#define PATH_TOKENS_MAX 40





static int createProcess(int* fds, int fd_i);
static void searchPath(Command* cmd);
static void chainPipes(int fdIn, int fdOut, int numStages, int* fdChain);
static void executeProcess(Command* stage /*, env */);

void sig_childHandler(int sig) {
    int status;
    pid_t pid = waitpid(-1, &status, WNOHANG);
    if (pid > 0) {
        char* pid_str = my_alloc(40 * sizeof(char));
        write(STDOUT_FILENO, "\n", 2);
        mystrlcpy(pid_str, "[PID ", 6);
        mystrlcat(pid_str, numtostr(pid), 40);
        mystrlcat(pid_str, "] finished\n", 40);
        write(STDOUT_FILENO, pid_str, 40);

        write(STDOUT_FILENO, SHELL_PROMPT, mystrlen(SHELL_PROMPT));
    }
}

/**
 * Returns -1 on failure
 */
int executeJob(Job* j) {
    //TODO set up filedescriptors between stages
    //TODO create process for each stage
    int fileDesIn = 0;
    int fileDesOut = 1;
    int fdChain[PIPELINE_MAX * 2] = { -1 };
    int childStatus = 0;
    pid_t children[PIPELINE_MAX] = { -1 };
    if (j->infile != NULL) {
        fileDesIn = open(j->infile, 0);
        if (fileDesIn == -1) {
            //error opening file
            myperror("open");
            return -1;
        }
    }
    if (j->outfile != NULL) {
        fileDesOut = open(j->outfile, O_WRONLY | O_CREAT | O_TRUNC, FILE_MODE); //create and truncate (overwrite)
        if (fileDesOut == -1) {
            //error opening file
            myperror("open");
            return -1;
        }
    }
    chainPipes(fileDesIn, fileDesOut, j->num_stages, fdChain);
    if (fdChain[0] == -1) {
        return -1;
    }
    for (int i = 0; i < j->num_stages; i++) {
        int fd_i = i * 2;
        children[i] = createProcess(fdChain, fd_i);
        if (children[i] == 0) {
            executeProcess(j->pipeline[i]);
        }
    }
    j->pgid = children[j->num_stages - 1];

    //close unused fds
    for (int i = 0; i < PIPELINE_MAX * 2; i++) {
        if (fdChain[i] != STDIN_FILENO && fdChain[i] != STDOUT_FILENO && fdChain[i] != -1) {
            close(fdChain[i]);
        }
    }

    if (j->background) {
        //background job here
        char* pid_str = my_alloc(40 * sizeof(char));
        mystrlcpy(pid_str, "[PID ", 6);
        mystrlcat(pid_str, numtostr(j->pgid), 40);
        mystrlcat(pid_str, "] started in background\n", 40);
        write(STDOUT_FILENO, pid_str, 40);
    }
    else {
        //wait for children to finish
        for (int i = 0; i < j->num_stages; i++) {
            waitpid(children[i], &childStatus, 0);
        }
    }
    return 0;
}


/**
 * Fills an array with an ordered set of file descriptors.
 * first and last index are either stdio or files. other indexes are pipes between processes.
 * eg: [infd, pipe1_write, pipe1_read, pipe2_write, pipe2_read, outfd]
 * first index is -1 on error.
 * @param fdChain is an array of size [MAX_PIPELINE * 2]
 * @param fdIn is either stdIn or a fd to an open file
 * @param fdOut is either stdOut or a fd to an open file
 * @param numStages is the number of stages/commands
 */
static void chainPipes(int fdIn, int fdOut, int numStages, int* fdChain) {
    int i = 0;
    int pipe_fd[2] = { -1, -1 };
    fdChain[i] = fdIn;
    for (i = 1; i < (numStages * 2) - 1; i += 2) {
        if (pipe(pipe_fd) == 0) {
            fdChain[i] = pipe_fd[1]; //write
            fdChain[i + 1] = pipe_fd[0]; //read
        }
        else {
            //error creating pipe
            myperror("pipe");
            fdChain[0] = -1;
            return;
        }
    }
    fdChain[i] = fdOut;
    return;
}

/**
 * Executes a process using execve
 * uses stage.argv as parameters and for filepath
 *
 */
static void executeProcess(Command* stage) {
    const char* pathname;
    //if path is given
    if (stage->argv[0][0] == '/' || stage->argv[0][0] == '.') {
        pathname = stage->argv[0];
        if (execve(pathname, (char* const*)stage->argv, __environ) == -1) {
            //Execution failed
            myperror(stage->argv[0]);
            if (errno == ENOENT)
                _exit(EXIT_CMD_NOT_FOUND); //command not found
            else
                _exit(EXIT_PERMISSION_DENIED); //command not executable
        }
    }
    else {
        //if name only given
        searchPath(stage);
    }
}

/**
 * Parent returns pid of child. Child returns -1
 */
static int createProcess(int* fds, int fd_i) {
    pid_t pid = fork();


    if (pid == 0) {
        //child process here
        if (fds[fd_i] != 0) {
            close(0);
            dup2(fds[fd_i], STDIN_FILENO);
        }
        if (fds[fd_i + 1] != 1) {
            close(1);
            dup2(fds[fd_i + 1], STDOUT_FILENO);
        }

        //close unused fds
        for (int i = 0; i < PIPELINE_MAX * 2; i++) {
            if (fds[i] != STDIN_FILENO && fds[i] != STDOUT_FILENO && fds[i] != -1) {
                close(fds[i]);
            }
        }


        return 0;
    }
    else {
        //parent process here
        return pid;
    }

}

/**
 * searches the PATH variable in the environment and calls execve. Does not return.
 * Exits on error
 *
 * @returns a string of the absolute path
 */
static void searchPath(Command* cmd) {
    char* env_paths = NULL;
    const char** tok_paths = my_alloc(sizeof(char*) * PATH_TOKENS_MAX);
    mymemset(tok_paths, 0, sizeof(char*) * PATH_TOKENS_MAX);

    int i = 0;
    while (__environ[i] != NULL) {
        if (mystrncmp("PATH=", __environ[i], 5) == 0) {
            env_paths = __environ[i] + 6;
            break;
        }
        i++;
    }
    if (env_paths != NULL) {
        int num_paths = tokenize(env_paths, tok_paths, ":", PATH_TOKENS_MAX);
        for (int k = 0; k < num_paths; k++) {

            if (!(mystrncmp(tok_paths[k], ":", 1) == 0)) {

                size_t path_len = sizeof(char) * (mystrlen(cmd->argv[0]) + mystrlen(tok_paths[k]) + 2 /*slash and \0*/);
                char* path = my_alloc(path_len);
                if (path) {
                    mystrlcpy(path, tok_paths[k], path_len);   //copy PATH var e.g. /bin
                    mystrncat(path, "/", 1);    //append / e.g. /bin/
                    mystrlcat(path, cmd->argv[0], path_len);    //add file name e.g. /bin/ls
                    if (execve(path, (char* const*)cmd->argv, __environ) == -1) {   //attempt execution
                        //Execution failed
                        if (errno == EACCES) {
                            myperror(cmd->argv[0]);
                            _exit(EXIT_PERMISSION_DENIED); //command not found
                        }
                        //otherwsie, try another
                    }
                }
                else {
                    _exit(1);
                }

            }
        }

    }
    myperror(cmd->argv[0]);
    _exit(EXIT_CMD_NOT_FOUND); //command not found
}
