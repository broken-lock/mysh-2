
#include "command.h"
#include "job.h"
#include "tokenizer.h"
#include "parser.h"
#include "utility.h"
#include "stdio.h"
#include "heap.h"
#include <unistd.h>
#include <signal.h>

#define SPECIAL_CHARS "|<>&"


void shell();
static inline int readline(const char** tokens);
static inline int checkExit(char* buffer);
static inline int checkNewline(char* buffer);
/*
static void printJob(Job* job);
static void printCommand(Command* com, int i);
void printTokens(const char** tokens);*/

int main(int argc, char* argv[]) {
    signal(SIGCHLD, sig_childHandler);
    shell();
    return 0;
}

/**
 * shell
 *
 * read evaluate print loop.
 * The main shell which reads inputs and prints outputs
 *
 */
void shell() {
    int exit = 0;
    while (!exit) {
        const char** tokens = my_alloc(ARG_MAX * sizeof(const char*));
        wwrite(1, SHELL_PROMPT, mystrlen(SHELL_PROMPT));

        int readStat = readline(tokens);
        if (readStat == 0) {

            Job* j;

            if (parse(tokens, &j)) {
                //printTokens(tokens);
                //printJob(j);
                executeJob(j);

            }
            j = NULL;   //j is freed in freeAll()
        }
        else if (readStat == 1) {
            exit = 1;
        }
        freeAll(); //reset heap after each job

    }

}



/**
 * Reads a line and tokenizes
 *
 * @param char** tokens, a pointer to a null terminated array of string tokens to be returned
 *
 * @returns 1 for exit, 0 for continue, -1 for skip parse and read new line
 */
static inline int readline(const char** tokens) {
    int exit = 0;
    char buffer[BUF_SIZE + 1] = { 0 };           //Max buffer length + null character to ensure it is always null terminated
    int readLen = 0;
    char* specials = SPECIAL_CHARS;

    readLen = read(0, buffer, BUF_SIZE);
    if (readLen < 0) {
        mysherror("Error reading from stdin");
        exit = -1;
    }
    else if (readLen == 0) {
        return -1;
    }
    else {
        if (checkExit(buffer))
            exit = 1;
        else if (checkNewline(buffer))
            return -1;

        int numTokens = tokenize(buffer, tokens, specials, ARG_MAX);
        if (numTokens == -1) {
            mysherror("Error tokenizing string");
            exit = -1;
        }

    }

    return exit;
}

static inline int checkExit(char* buffer) {
    if (!buffer)
        return 0;
    return (mystrncmp("exit\n", buffer, 5) == 0);
}

static inline int checkNewline(char* buffer) {
    if (!buffer)
        return 0;
    return (mystrncmp("\n", buffer, 1) == 0);
}


/*

*
 * Testing Function to check job object state after parse

static void printJob(Job* job) {
    printf("Job program ID: %d\n", job->pgid);
    printf("number of stages: %ld\n", job->num_stages);
    printf("infile: \'%s\'\n", job->infile);
    printf("outfile: \'%s\'\n", job->outfile);
    if (job->background)
        printf("background: True\n");
    else
        printf("background: false\n");
    printf("pipeline: \n");
    for (int i = 0; i < PIPELINE_MAX; i++) {
        if (job->pipeline[i] != NULL) {
            printCommand(job->pipeline[i], i);
        }
        else {
            break;
        }
    }

}

*
 * Testing function to check command obect state after parse

static void printCommand(Command* com, int i) {
    printf("command_%d\n", i);
    printf("\tpid: %d\n", com->pid);
    printf("\targ count: %u\n", com->argc);
    printf("\targs:\n");
    for (int j = 0; j < com->argc + 1; j++) {
        if (com->argv[j] == NULL)
            printf("\t\targ %d: NULL\n", j);
        else
            printf("\t\targ %d: \'%s\'\n", j, com->argv[j]);
    }
    printf("\tflags: %X\n\n", com->flags);
}


void printTokens(const char** tokens) {
    if (!tokens) {
        printf("tokens array is null\n");
        return;
    }
    int i = 0;
    char* s = tokens[i];
    printf("tokens:");
    while (s) {
        printf(" \'%s\',", s);
        i++;
        s = tokens[i];
    }
    printf("\n\n");
    return;
}
*/


