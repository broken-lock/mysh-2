#ifndef HEAP_H
#define HEAP_H

#include <sys/types.h>
#include <stdint.h>

#define HEAP_SIZE 16384


#ifndef NULL
#define NULL ((void*)0)
#endif


#define ALIGN8(x) (((x) + 7) & ~7) //Aligns memory to 8 byte values

void* my_alloc(size_t size);

void freeAll();


#endif