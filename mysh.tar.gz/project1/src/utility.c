#include "utility.h"

#include <ctype.h>
#include <errno.h>
#include <stdarg.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>

#include "global.h"
#include "heap.h"



/*
  POSIX standard string functions.
*/
size_t mystrlen(const char* s) {
  size_t i = 0;
  while (s[i]) {
    i++;
  }
  return i;
}

/**
 * Assumes num is a 32 bit signed integer
 *
 * @returns a null terminated representation of the string allocated on the heap (remember to freeAll() periodically)
 */
char* numtostr(int num) {
  char* s = my_alloc(sizeof(char) * 12);
  int len = 0;
  long n = num;
  if (n == 0) {
    s[len++] = '0';
    s[len] = '\0';
    return s;
  }


  if (n < 0) {
    s[len++] = '-';
    n = -n;
  }
  int start = len;

  while (n > 0) {
    s[len++] = '0' + (n % 10); //convert to digits in reverse
    n /= 10;
  }

  for (int j = 0; j < (len - start) / 2; j++) { //reverse digits back in order
    char tmp = s[start + j];
    s[start + j] = s[len - 1 - j];
    s[len - 1 - j] = tmp;
  }

  s[len] = '\0';
  return s;
}


static inline int append(char** dst, const char* src, size_t* rem) {
  char* p = *dst;

  if (!*rem) {
    return 0;
  }

  while ((*rem) > 1 && *src) {
    *p++ = *src++;
    (*rem)--;
  }

  *p = '\0';
  *dst = p;

  return (*src == '\0');
}

int mystrcmp(const char* s1, const char* s2) {
  while (*s1 && *s1 == *s2) {
    s1++;
    s2++;
  }
  return (unsigned char)*s1 - (unsigned char)*s2;
}

int mystrncmp(const char* s1, const char* s2, size_t n) {
  if (!n) {
    return 0;
  }
  while (--n && *s1 && *s1 == *s2) {
    s1++;
    s2++;
  }
  return (unsigned char)*s1 - (unsigned char)*s2;
}

char* mystrncpy(char* dst, const char* src, size_t n) {
  if (!n) {
    return dst;
  }
  size_t i = 0;
  for (; i < n && src[i]; i++) {
    dst[i] = src[i];
  }

  for (; i < n; i++) {
    dst[i] = '\0';
  }

  return dst;
}

char* mystrncat(char* dst, const char* src, size_t n) {
  size_t dlen = mystrlen(dst);
  char* p = dst + dlen;
  size_t i = 0;

  for (; i < n && src[i]; i++) {
    p[i] = src[i];
  }

  p[i] = '\0';

  return dst;
}

char* mystrndup(const char* src, size_t n) {
  size_t len = 0;
  while (len < n && src[len]) {
    len++;
  }

  char* dst = (char*)my_alloc(len + 1);

  if (!dst) {
    return NULL;
  }

  mystrlcpy(dst, src, len + 1);
  dst[len] = '\0';

  return dst;
}

/*
  BSD style string functions, safer than the strn* functions.
  We'll just use whichever one's are less of a pain.
 */
size_t mystrlcpy(char* dst, const char* src, size_t n) {
  size_t ret = mystrlen(src);
  if (!n) {
    return ret;
  }
  size_t i = 0;
  while (i < n - 1 && src[i]) {
    dst[i] = src[i];
    i++;
  }

  dst[i] = '\0';

  return ret;
}

size_t mystrlcat(char* dst, const char* src, size_t size) {
  size_t dlen = 0;
  for (; dlen < size && dst[dlen]; dlen++) {
  }

  size_t slen = mystrlen(src);

  if (dlen == size) {
    return dlen + slen;
  }

  dst += dlen;
  size_t i = 0;
  size -= (dlen + 1);
  for (; i < size && src[i]; i++) {
    dst[i] = src[i];
  }

  dst[i] = '\0';

  return dlen + slen;
}

const char* mystrchr(const char* s, char c) {
  while (*s && *s != c) {
    s++;
  }
  return *s ? s : NULL;
}

/*
  Check if a character exists in a string.
*/
int charinstr(char c, const char* s) {
  while (*s) {
    if (*s++ == c) {
      return 1;
    }
  }
  return 0;
}

/*
  Check if a string exists ina set.
*/
int strinset(char* str, const char* set[]) {
  if (str && set) {
    while (*set) {
      if (mystrcmp(str, *set++) == 0) {
        return 1;
      }
    }
  }
  return 0;
}

/*
  memset, if we need to limit the C library functions we're allowed to use.
*/
void mymemset(void* dst, unsigned char val, size_t n) {
  unsigned char* p = (unsigned char*)dst;
  if (dst) {
    while (n--) {
      *p++ = val;
    }
  }
}

/*
  For path searches.
*/
int join_path(char* dst, const char* dir, const char* filename, size_t rem) {
  char* p = dst;

  if (append(&p, dir, &rem)) {
    return 0;
  }

  if (p > dst && p[-1] != '/') {
    if (append(&p, "/", &rem)) {
      return 0;
    }
  }

  if (append(&p, filename, &rem)) {
    return 0;
  }

  return 1;
}

/**
 * Read wrapper, handles the errors. Guarantees that the read finishes.
 *
 *
*/
ssize_t wread(int fd, char* buf, size_t count) {
  size_t n = 0;
  while (n < count) {
    ssize_t ret = read(fd, buf + n, count - n);
    if (ret < 0) {
      if (errno == EINTR) {
        continue;
      }
      return -1;
    }
    else if (ret == 0) {
      break;
    }
    n += ret;
  }
  return n;
}

/*
  Write wrapper, handles the errors. Guarantees that the write finishes.
*/
ssize_t wwrite(int fd, const char* buf, size_t count) {
  size_t n = 0;
  while (n < count) {
    ssize_t ret = write(fd, buf + n, count - n);
    if (ret < 0) {
      if (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK) {
        continue;
      }
      return -1;
    }
    n += ret;
  }
  return n;
}

/*
  Just incase we're not allowed to use the perror function
*/
void myperror(const char* prefix) {
  char msg[BUF_SIZE];
  char* p = msg;
  size_t rem = BUF_SIZE - 1;
  const char* estr = strerror(errno);

  if (prefix && *prefix) {
    append(&p, prefix, &rem);
  }

  if (rem > 2 && estr && *estr) {
    append(&p, ": ", &rem);
    append(&p, estr, &rem);
  }
  *p++ = '\n';
  wwrite(STDERR_FILENO, msg, (size_t)(p - msg));
}


void mysherror(const char* fst, ...) {
  char msg[BUF_SIZE];
  va_list args;
  const char* str, * sn = SHELL_PROMPT;
  char* p = msg;
  size_t rem = BUF_SIZE - 1;

  append(&p, sn, &rem);

  va_start(args, fst);
  for (str = fst; rem > 2 && str; str = va_arg(args, const char*)) {
    append(&p, ": ", &rem);
    append(&p, str, &rem);
  }
  va_end(args);
  *p++ = '\n';
  wwrite(STDERR_FILENO, msg, (size_t)(p - msg));
}
