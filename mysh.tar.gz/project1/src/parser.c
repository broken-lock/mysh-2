#include "utility.h"
#include "heap.h"
#include "command.h"
#include "job.h"

/*
  Parser module. Probably not a good practice to have it make use of
  global variables to the extent we do here, but parsing isn't really
  gonna be done non-sequentially by two or more workers that we have to
  worry about reentrancy and safety.
*/



/* Syntax error codes */
typedef enum {
  OK = 0,
  CMD_LIM_ERR,
  PIPE_LIM_ERR,
  TOKEN_ERR,
} ParseError;

/*
  A simple structure to represent the parsing status.
*/
typedef struct {
  ParseError error;
  const char* expected;
  const char* found;
} ParseStat;

const char** curr;
static ParseStat parse_stat = { .error = OK, .expected = NULL, .found = NULL };

const char* op_terms[] = { "|", "<", ">", "&", NULL };


static inline int accept(const char*);
static inline void advance();
static inline int is_word(const char*);
static void print_error();
static inline void set_stat(ParseError error, const char* expected, const char* found);
static int parse_job(Job** job);
static int parse_pipeline(Command* p[], size_t* nstages);
static int parse_command(Command** cmd);



static inline const char* peek() {
  return (curr && *curr) ? *curr : NULL;  //check if curr is not null
}

static inline int accept(const char* s) {
  // Checks for acceptance, and then consumes the current token, i.e., advance.
  if (*curr && mystrcmp(*curr, s) == 0) {
    curr++;
    return 1;
  }
  return 0;
}

static inline void advance() {
  // Advance only when not at the end.
  if (*curr) {
    curr++;
  }
}

static inline int is_word(const char* s) {
  // "word" is equivalent to TOKEN in the CFG sense, but token during parsing
  // refers to terminals and non-terminals alike.
  return s && !strinset((char*)s, op_terms);
}

static inline void set_stat(ParseError error, const char* expected, const char* found) {
  // Setting the current parsing status
  parse_stat = (ParseStat){
    .error = error,
    .expected = expected,
    .found = found ? found : "newline"
  };
}

static void print_error() {
  switch (parse_stat.error) {
  case CMD_LIM_ERR:
    mysherror("syntax error command exceeded ARG_MAX", NULL);
    break;
  case PIPE_LIM_ERR:
    mysherror("syntax error job stages exceeded PIPELINE_MAX", NULL);
    break;
  case TOKEN_ERR:
    mysherror("syntax error near unexpected token", parse_stat.found, NULL);
    break;
  default:
    mysherror("Unspecified error occured");
  }
}

static int parse_command(Command** cmd) {
  if (!is_word(peek())) {
    set_stat(TOKEN_ERR, "command", peek());
    return 0;
  }

  Command* c = (Command*)my_alloc(sizeof(Command));
  if (c)
    mymemset(c, 0, sizeof(Command));
  else {
    mysherror("unable to allocate memory for command", NULL, NULL);
    return 0;
  }

  while (is_word(peek())) {
    if (c->argc >= ARG_MAX) {
      set_stat(CMD_LIM_ERR, NULL, NULL);
      return 0;
    }
    c->argv[c->argc++] = mystrndup(peek(), mystrlen(peek()));
    advance();
  }
  c->argv[c->argc] = NULL;
  *cmd = c;
  c->pid = -1;
  return 1;
}




static int parse_pipeline(Command* p[], size_t* nstages) {
  size_t stage = 0;

  if (stage >= PIPELINE_MAX) {
    set_stat(PIPE_LIM_ERR, NULL, NULL);
    return 0;
  }

  if (!parse_command(&p[stage])) {
    return 0;
  }
  stage++;

  while (accept("|")) {
    if (!peek()) {
      set_stat(TOKEN_ERR, "command", NULL);
      return 0;
    }
    if (stage >= PIPELINE_MAX) {
      set_stat(PIPE_LIM_ERR, NULL, NULL);
      return 0;
    }
    if (!parse_command(&p[stage])) {
      return 0;
    }
    stage++;
  }
  *nstages = stage;

  return 1;
}

static int parse_job(Job** job) {
  Job* j = (Job*)my_alloc(sizeof(Job));
  if (j)
    mymemset(j, 0, sizeof(Job));
  else {
    mysherror("memory error occured. Unable to allocated memory for Job", NULL, NULL);
    return 0;
  }


  if (!parse_pipeline(j->pipeline, &j->num_stages)) {
    return 0;
  }
  if (accept("<")) {
    if (is_word(peek())) {
      j->infile = mystrndup(peek(), mystrlen(peek()));
      advance();
    }
    else {
      set_stat(TOKEN_ERR, "filename", peek());
      return 0;
    }
  }
  if (accept(">")) {
    if (is_word(peek())) {
      j->outfile = mystrndup(peek(), mystrlen(peek()));
      advance();
    }
    else {
      set_stat(TOKEN_ERR, "filename", peek());
      return 0;
    }
  }
  if (accept("&")) {
    j->background = 1;
  }
  if (peek()) {
    set_stat(TOKEN_ERR, "end-of-line", peek());
    return 0;
  }

  *job = j;
  j->pgid = -1;
  return 1;
}



int parse(const char* tokens[], Job** j) {
  curr = tokens;
  parse_stat.error = OK;

  if (parse_job(j)) {
    return 1;
  }

  print_error();
  return 0;
}