#ifndef TOKENIZER_H
#define TOKENIZER_H

#include <sys/types.h>

/* tokenizing */
int tokenize(const char* buf, const char* tokens[], const char* special, size_t n);

#endif
