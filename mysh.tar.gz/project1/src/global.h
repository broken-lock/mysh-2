
#ifndef NULL
#define NULL ((void*)0)
#endif

#define BUF_SIZE 4096 /*4096 bytes*/

#define SHELL_NAME "My_Shell"
#define SHELL_SYMB  "$ "
#define SHELL_PROMPT SHELL_NAME SHELL_SYMB