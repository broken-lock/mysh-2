#include "utility.h"
#include "global.h"
#include <ctype.h>




/*
  Tokenizer helper.
*/
int get_token(const char* src, const char* special, const char** token) {
  if (!src || !token) {
    return -1;
  }

  const char* start = src;
  while (isspace(*start)) {
    start++;
  }

  if (!*start) {
    return 0;
  }

  const char* end = start;
  int is_special = special && charinstr(*end, special);

  while (*end && !isspace(*end)) {
    if (special && is_special != charinstr(*end, special)) {
      break;
    }
    end++;
  }

  *token = mystrndup(start, end - start);
  if (!*token) {
    return -1;
  }

  return end - src;
}

int tokenize(const char* buf, const char* tokens[], const char* special, size_t n) {
  size_t i = 0;
  int nchars;

  for (; i < n - 1 && *buf; i++) {
    nchars = get_token(buf, special, &tokens[i]);
    if (nchars == -1) {
      return -1;
    }
    buf += nchars;
  }
  tokens[i] = NULL;
  return i;
}
