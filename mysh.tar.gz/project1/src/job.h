#ifndef JOB_H
#define JOB_H


#include "command.h"
#define PIPELINE_MAX 16

typedef struct Job {
    Command* pipeline[PIPELINE_MAX];
    size_t num_stages;
    const char* infile;
    const char* outfile;
    int background;
    int pgid;
} Job;

int executeJob(Job* j);
void sig_childHandler(int sig);
#endif