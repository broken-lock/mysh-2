#ifndef UTILITY_H
#define UTILITY_H

//#include <stddef.h>
#include <sys/types.h>

/*
  We'll just weed out the unnecessary one later on.
*/

/* Typical POSIX string functions, and some helpers */
size_t mystrlen(const char* s);
int mystrcmp(const char* s1, const char* s2);
int mystrncmp(const char* s1, const char* s2, size_t n);
//void mystrcpy(char* dst, char* src);
size_t mystrlcpy(char* dst, const char* src, size_t n);
char* mystrncpy(char* dst, const char* src, size_t n);
char* mystrncat(char* dst, const char* src, size_t n);
char* mystrndup(const char* src, size_t n);
const char* mystrchr(const char* s, char c);
char* numtostr(int num);

/* helpers */
int charinstr(char c, const char* s);
int strinset(char* str, const char* set[]);
void mymemset(void* dst, unsigned char val, size_t n);

/* BSD string functions */
size_t mystrlcpy(char* dst, const char* src, size_t n);
size_t mystrlcat(char* dst, const char* src, size_t n);

/* path */
int join_path(char* dst, const char* dir, const char* file, size_t n);

/* io */
ssize_t wread(int fd, char* buf, size_t n);
ssize_t wwrite(int fd, const char* buf, size_t n);

/* error */
void myperror(const char* prefix);
void mysherror(const char* fst, ...);

#endif
