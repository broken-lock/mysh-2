#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "../src/heap.h"
#include "../src/job.h"
#include "../src/command.h"

int main(void) {
    printf("Running allocator tests...\n");

    // 1️ Basic allocation
    int* a = my_alloc(sizeof(Job));
    assert(a != NULL);
    *a = 42;
    assert(*a == 42);

    // 2️ Multiple allocations
    int* b = my_alloc(sizeof(Job));
    assert(b != NULL);
    *b = 100;
    assert(*b == 100);

    // test they don't overlap
    assert(a != b);

    // 3️ Allocate array and write into it
    int* arr = my_alloc(10 * sizeof(Command));
    assert(arr != NULL);

    for (int i = 0; i < 10; i++)
        arr[i] = i;

    for (int i = 0; i < 10; i++)
        assert(arr[i] == i);

    // 4️ Out of memory test
    void* big = my_alloc(100000);  // bigger than heap
    assert(big == NULL);

    // 5️ Reset test
    freeAll();

    int* c = my_alloc(sizeof(Command));
    assert(c != NULL);
    *c = 555;
    assert(*c == 555);

    printf("All tests passed.\n");
    return 0;
}