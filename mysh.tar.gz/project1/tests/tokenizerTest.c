#include "../src/tokenizer.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    const char* line = "ls -l | grep foo > out.txt &";
    char* tokens[20];
    const char* special = "|&<>";

    int ntokens = tokenize(line, tokens, special, 20);
    if (ntokens == -1) {
        printf("Tokenizer error!\n");
        return 1;
    }

    printf("Tokenized %d tokens:\n", ntokens);
    for (int i = 0; i < ntokens; i++) {
        printf("  tokens[%d] = '%.*s'\n", i,
            (int)(strchr(" |&<>", tokens[i][0]) ? 1 : strlen(tokens[i])),
            tokens[i]);
    }

    return 0;
}