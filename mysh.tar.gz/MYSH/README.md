# Linux Shell Project

**Description:**  
A minimal Unix shell implementation written in C.
This project was built to explore core operating system concepts including process creation, program execution, signal handling, pipes, and basic job control.

---

## Features

- Tokenizing and parsing commands to create Jobs
- Execute external programs using `fork()` and `execve()`
- Support for foreground and background execution (`&`)
- Pipeline support (`|`) for N stages
- I/O redirection (`<`, `>`)
- Manual `PATH` resolution with POSIX colon semantics
- Process groups and terminal ownership via `tcsetpgrp()`
- Signal handling: SIGINT, SIGCHLD, SIGTSTP, SIGTTIN, SIGTTOU, SIGQUIT
- Built-in commands: `exit`, `help`, `cd`, `jobs`, `fg`, `bg`
- Job table with MRU tracking and status notifications
- Arena allocator with 8-byte aligned bump allocation
- Can run as an interactive login shell

---

## Building

    make            # build mysh
    make clean      # remove build artifacts

---

## Limitations

This is a learning-focused implementation and does not aim to fully replicate a POSIX-compliant shell. It does not support quoting, shell variables, expansion, globbing, command lists (`;`, `&&`, `||`), heredocs, append redirection (`>>`), command history, or line editing.

---

## Purpose

Built as part of an Operating Systems course project (COMP 3659) to gain hands-on experience with low-level Unix system calls and process control.