#ifndef BUILTIN_H
#define BUILTIN_H

#include "jobtable.h"

int run_builtin(const char *tokens[], JobTable *tbl);

#endif
