#include "sh_util.h"

#include <errno.h>
#include <unistd.h>

ssize_t sh_read(int fd, char *buf, size_t count) {
  size_t n = 0;

  while (n < count) {
    ssize_t ret = read(fd, buf + n, count - n);

    if (ret < 0) {
      if (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK)
        continue;
      return -1;
    } else if (ret == 0) {
      break;
    }
    n += (size_t)ret;
  }

  return (ssize_t)n;
}

ssize_t sh_write(int fd, const char *buf, size_t count) {
  size_t n = 0;

  while (n < count) {
    ssize_t ret = write(fd, buf + n, count - n);

    if (ret < 0) {
      if (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK)
        continue;
      return -1;
    }
    n += (size_t)ret;
  }

  return (ssize_t)n;
}
