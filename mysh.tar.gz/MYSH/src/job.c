#include "job.h"

#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

#include "error.h"
#include "path.h"
#include "sig.h"
#include "str.h"
#include "xmalloc.h"

#define READ_END 0
#define WRITE_END 1
#define FILE_MODE 0644

extern pid_t shell_pgrp;
extern char **shell_envp;
extern int shell_tty;

/*
 * safe_dup2 - duplicate fd, no-op if old == new.
 */
static int safe_dup2(int old_fd, int new_fd) {
  if (old_fd == new_fd)
    return 0;

  if (dup2(old_fd, new_fd) == -1) {
    sh_perror("dup2");
    return -1;
  }

  return 0;
}

/*
 * safe_pipe - create pipe, initializing fds to NO_FD on failure.
 */
static int safe_pipe(int pipe_fd[]) {
  pipe_fd[READ_END] = NO_FD;
  pipe_fd[WRITE_END] = NO_FD;

  if (pipe(pipe_fd) == -1) {
    sh_perror("pipe");
    return -1;
  }

  return 0;
}

static int safe_tcsetpgrp(int fd, pid_t pgid) {
  if (tcsetpgrp(fd, pgid) == -1) {
    sh_perror("tcsetpgrp");
    return -1;
  }

  return 0;
}

static int give_terminal_to(pid_t pgid) {
  if (safe_tcsetpgrp(shell_tty, pgid) == -1)
    return -1;

  return 0;
}

/*
 * redirect - open file and dup2 onto target fd.
 */
static int redirect(const char *file, int new_fd, int flags, int mode) {
  int fd;

  if ((fd = open(file, flags, mode)) == -1) {
    sh_error(file, strerror(errno), NULL);
    return -1;
  }

  if (safe_dup2(fd, new_fd) == -1)
    return -1;

  close(fd);
  return 0;
}

/*
 * set_jobpgrp - assign pid to the job's process group, creating it if needed.
 */
static int set_jobpgrp(Job *job, pid_t pid) {
  pid_t pgid = job->pgid;

  if (pgid == -1) {
    pgid = pid;
    job->pgid = pid;
  }

  if (setpgid(pid, pgid) == -1) {
    sh_perror("setpgid");
    return -1;
  }

  return 0;
}

/*
 * chain_pipes - pre-build an array of file descriptors for a pipeline.
 *
 * Layout: [in0, out0, in1, out1, ..., inN, outN]
 *   - fd_chain[0]         = stdin  (or NO_FD)
 *   - fd_chain[last]      = stdout (or NO_FD)
 *   - interior pairs are pipe read/write ends
 *
 * Returns 0 on success, -1 on error.
 */
static int chain_pipes(int fd_chain[], size_t num_stages) {
  int pipe_fd[2];

  fd_chain[0] = STDIN_FILENO;
  for (size_t i = 1; i < (num_stages * 2) - 1; i += 2) {
    if (safe_pipe(pipe_fd) == -1)
      return -1;
    fd_chain[i] = pipe_fd[WRITE_END];
    fd_chain[i + 1] = pipe_fd[READ_END];
  }
  fd_chain[(num_stages * 2) - 1] = STDOUT_FILENO;

  return 0;
}

/*
 * handle_stages - wire up stdin/stdout for a pipeline stage.
 *
 * Each stage reads from fd_chain[i*2] and writes to fd_chain[i*2+1].
 * Applies file redirections on the first and last stages.
 * Closes all inherited chain fds.
 */
static int handle_stages(Job *job, size_t stage, int fd_chain[]) {
  size_t num_stages = job->num_stages;
  size_t fd_i = stage * 2;

  if (fd_chain[fd_i] != STDIN_FILENO) {
    if (safe_dup2(fd_chain[fd_i], STDIN_FILENO) == -1)
      return -1;
  }

  if (fd_chain[fd_i + 1] != STDOUT_FILENO) {
    if (safe_dup2(fd_chain[fd_i + 1], STDOUT_FILENO) == -1)
      return -1;
  }

  if (stage == 0 && job->in_file &&
      redirect(job->in_file, STDIN_FILENO, O_RDONLY, 0) == -1)
    return -1;

  if (stage == num_stages - 1 && job->out_file &&
      redirect(job->out_file, STDOUT_FILENO, O_CREAT | O_WRONLY | O_TRUNC,
               FILE_MODE) == -1)
    return -1;

  for (size_t i = 0; i < num_stages * 2; i++) {
    if (fd_chain[i] != STDIN_FILENO && fd_chain[i] != STDOUT_FILENO)
      close((int)fd_chain[i]);
  }

  return 0;
}

/*
 * spawn - fork and exec a single pipeline stage.
 *
 * Child sets its process group, resolves the command path,
 * wires up fds, resets signals, and execs.
 */
static pid_t spawn(Job *job, size_t stage, int fd_chain[]) {
  Command *cmd = job->pipeline[stage];
  char *path;
  pid_t pid;

  cmd->pid = NO_PID;

  if ((pid = fork()) == -1) {
    sh_perror("fork");
  } else if (pid == 0) {
    if (set_jobpgrp(job, getpid()) == -1)
      exit(EXIT_FAILURE);

    path = path_resolve(cmd->argv[0], shell_dirs);
    if (!path)
      exit(path_error(cmd->argv[0]));

    if (handle_stages(job, stage, fd_chain) == -1)
      exit(EXIT_FAILURE);

    sig_init_child();

    execve(path, cmd->argv, shell_envp);
    sh_error(cmd->argv[0], strerror(errno), NULL);
    exit(EXIT_FAILURE);
  }

  return pid;
}

/*
 * job_fg_wait - wait for a foreground job and reclaim the terminal.
 */
int job_fg_wait(Job *job) {
  job_update(job, WUNTRACED);

  if (give_terminal_to(shell_pgrp) == -1)
    return -1;

  return 0;
}

/*
 * job_run - launch all stages of a job.
 *
 * Pre-builds the pipe chain, then forks each pipeline stage.
 * Foreground jobs are waited on immediately.
 */
int job_run(Job *job) {
  int fd_chain[PIPELINE_MAX * 2];
  pid_t pid;
  size_t num_stages = job->num_stages;
  int spawned = 0, gave_terminal = 0;

  job->pgid = NO_PID;

  if (chain_pipes(fd_chain, num_stages) == -1)
    return -1;

  for (size_t i = 0; i < num_stages; i++) {
    if ((pid = spawn(job, i, fd_chain)) == -1)
      goto cleanup;

    spawned = 1;
    if (set_jobpgrp(job, pid) == -1)
      goto cleanup;

    if (i == 0 && !job->background) {
      if (give_terminal_to(job->pgid) == -1)
        goto cleanup;
      gave_terminal = 1;
    }

    job->pipeline[i]->pid = pid;
  }

  /* close all pipe fds in parent */
  for (size_t i = 0; i < num_stages * 2; i++) {
    if (fd_chain[i] != STDIN_FILENO && fd_chain[i] != STDOUT_FILENO)
      close(fd_chain[i]);
  }

  job->finished = 0;

  if (!job->background)
    job_fg_wait(job);

  return 0;

cleanup:
  for (size_t i = 0; i < num_stages * 2; i++) {
    if (fd_chain[i] != STDIN_FILENO && fd_chain[i] != STDOUT_FILENO &&
        fd_chain[i] != NO_FD)
      close(fd_chain[i]);
  }

  if (gave_terminal)
    give_terminal_to(shell_pgrp);

  if (spawned && job->pgid > 0)
    job_cleanup(job, 0);

  return -1;
}

/*
 * job_update - collect status changes for a job's process group.
 *
 * Breaks on stop, exit of the last process, or ECHILD.
 */
int job_update(Job *job, int opts) {
  pid_t pid;
  int status;
  Command *last = job->pipeline[job->num_stages - 1];

  do {
    pid = waitpid(-(job->pgid), &status, opts);
    if (pid == -1) {
      if (errno == ECHILD) {
        job->finished = 1;
        break;
      } else if (errno == EINTR) {
        continue;
      }
      return -1;
    } else if (pid > 0) {
      if (WIFSTOPPED(status)) {
        job->stopped = 1;
        break;
      } else if (WIFCONTINUED(status)) {
        job->stopped = 0;
      }

      if (pid == last->pid && (WIFEXITED(status) || WIFSIGNALED(status))) {
        last->status = status;
        job->finished = 1;
        break;
      }
    }
  } while (pid > 0);

  return pid;
}

/*
 * job_resume - send SIGCONT to a stopped job.
 */
int job_resume(Job *job) {
  if (job->stopped) {
    if (kill(-(job->pgid), SIGCONT) == -1) {
      if (errno != ESRCH) {
        sh_perror("kill");
        return -1;
      }
    }
  }

  return 0;
}

/*
 * job_bg_resume - continue a stopped job in the background.
 */
int job_bg_resume(Job *job) {
  if (job_resume(job) == -1)
    return -1;

  if (job_update(job, WNOHANG | WCONTINUED | WUNTRACED) == -1)
    return -1;

  return 0;
}

/*
 * job_fg_resume - bring a background job to the foreground.
 */
int job_fg_resume(Job *job) {
  if (give_terminal_to(job->pgid) == -1)
    return -1;

  if (job_resume(job) == -1)
    return -1;

  job->background = 0;

  if (job_fg_wait(job) == -1)
    return -1;

  return 0;
}

/*
 * job_cleanup - terminate a job's process group.
 *
 * Sends SIGTERM, waits, then SIGKILL if still alive.
 */
void job_cleanup(Job *job, unsigned int secs) {
  pid_t pid;
  int status;

  kill(-(job->pgid), SIGTERM);
  sleep(secs);

  do {
    pid = waitpid(-(job->pgid), &status, WNOHANG | WCONTINUED | WUNTRACED);
    if (pid == -1 && errno == ECHILD)
      break;
  } while (pid > 0 || (pid == -1 && errno == EINTR));

  if (kill(-(job->pgid), 0) == 0) {
    if (kill(-(job->pgid), SIGKILL) == -1 && errno == EPERM)
      return;

    do {
      pid = waitpid(-(job->pgid), &status, 0);
      if (pid == -1 && errno == ECHILD)
        break;
    } while (pid > 0 || (pid == -1 && errno == EINTR));
  } else if (errno == EPERM) {
    return;
  }
}
