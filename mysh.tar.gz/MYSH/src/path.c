#include "path.h"

#include <errno.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include "error.h"
#include "str.h"
#include "xmalloc.h"

/*
 * path_init - extract PATH from envp.
 *
 * Falls back to a sensible default if PATH is unset or empty.
 */
void path_init(char *envp[]) {
  shell_dirs = NULL;

  for (size_t i = 0; envp[i]; i++) {
    if (my_strncmp("PATH=", envp[i], 5) == 0) {
      shell_dirs = envp[i] + 5;
      break;
    }
  }

  /* The sensible default */
  if (!shell_dirs || !*shell_dirs)
    shell_dirs = "/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/sbin:/usr/local/bin";
}

/*
 * path_next - extract the next directory from a colon-separated list.
 *
 * Advances *idx past the consumed segment and leaves it pointing at the ':'.
 * An empty component (leading, trailing, or double colon) returns ".".
 *
 * Returns a heap-allocated directory name, or NULL at end of string.
 */
char *path_next(const char *dirs, int *idx) {
  const char *start, *end;

  if (!dirs[*idx])
    return NULL;

  if (dirs[*idx] == ':')
    (*idx)++;

  start = dirs + *idx;
  end = start;

  while (*end && *end != ':')
    end++;

  *idx += (int)(end - start);

  if (end == start)
    return my_strndup(".", 1);

  return my_strndup(start, (size_t)(end - start));
}

/*
 * path_name_extract - return the basename of a path.
 *
 * Returns a pointer into the original string, not a copy.
 */
const char *path_name_extract(const char *path) {
  const char *base = path;

  for (; *path; path++) {
    if (*path == '/' && *(path + 1))
      base = path + 1;
  }

  return base;
}

/*
 * path_join - concatenate dir and name with a "/" separator.
 *
 * Returns a heap-allocated path, or NULL.
 */
char *path_join(const char *dir, const char *name) {
  size_t dlen, nlen, rem;
  char *path, *p;

  dlen = my_strlen(dir);
  nlen = my_strlen(name);
  rem = dlen + nlen + 2;

  path = (char *)xmalloc(rem);
  if (!path)
    return NULL;

  p = path;
  append(&p, dir, &rem);
  if (p > path && p[-1] != '/')
    append(&p, "/", &rem);
  append(&p, name, &rem);

  return path;
}

/*
 * path_is_executable - check if name is a regular, executable file.
 *
 * Sets errno on failure: EISDIR for directories, EACCES for
 * non-regular files or missing execute permission.
 *
 * Returns 1 if executable, 0 otherwise.
 */
static inline int path_is_executable(const char *name) {
  struct stat st;

  if (stat(name, &st) == -1)
    return 0;

  if (!S_ISREG(st.st_mode)) {
    errno = S_ISDIR(st.st_mode) ? EISDIR : EACCES;
    return 0;
  }

  if (access(name, X_OK) == -1)
    return 0;

  return 1;
}

/*
 * path_resolve - find the full pathname of a command.
 *
 * If name contains '/', it is checked directly.
 * Otherwise each directory in the colon-separated dirs string is tried.
 *
 * Returns a heap-allocated pathname on success, NULL if not found.
 */
char *path_resolve(const char *name, const char *dirs) {
  char *dir, *full;
  int idx, found = 0;

  if (my_strchr(name, '/')) {
    if (path_is_executable(name))
      return my_strndup(name, my_strlen(name));
    return NULL;
  }

  idx = 0;
  while ((dir = path_next(dirs, &idx))) {
    full = path_join(dir, name);

    if (!full)
      continue;

    if (path_is_executable(full))
      return full;

    if (errno != ENOENT)
      found = 1;
  }

  errno = found ? EACCES : ENOENT;
  return NULL;
}

/*
 * path_error - print a diagnostic and return the appropriate exit code.
 *
 * Direct paths (contain '/') get the system error message from errno.
 * Bare names get "command not found" or the system error if found but
 * not executable.
 *
 * Returns 126 (found but not executable) or 127 (not found).
 *
 * Must be called immediately after path_resolve fails.
 */
int path_error(const char *name) {
  int errnum = errno;

  if (my_strchr(name, '/')) {
    sh_error(name, strerror(errnum), NULL);
    return errnum == ENOENT || errnum == ENOTDIR ? 127 : 126;
  }

  if (errnum == EACCES) {
    sh_error(name, strerror(errnum), NULL);
    return 126;
  }

  sh_error(name, "command not found", NULL);
  return 127;
}
