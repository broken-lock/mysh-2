#include <errno.h>
#include <fcntl.h>
#include <unistd.h>

#include "builtin.h"
#include "error.h"
#include "global.h"
#include "job.h"
#include "jobtable.h"
#include "parser.h"
#include "path.h"
#include "sh_util.h"
#include "sig.h"
#include "str.h"
#include "tok.h"
#include "xmalloc.h"

/* shell globals */
pid_t shell_pgrp;
const char *shell_name = "mysh";
const char *shell_dirs;
char **shell_envp;
int shell_tty = NO_FD;

static const char *prompt;
static JobTable tbl;

/*
 * shell_init - set up terminal, signals, process group, and PATH.
 */
static int shell_init(char **argv, char **envp) {
  shell_pgrp = getpid();
  shell_name = path_name_extract(argv[0]);
  shell_envp = envp;
  prompt = shell_name;

  shell_tty = open("/dev/tty", O_RDWR);
  if (shell_tty == -1) {
    sh_perror("/dev/tty");
    return -1;
  }

  if (sig_init() == -1)
    return -1;

  if (setpgid(shell_pgrp, shell_pgrp) == -1)
    return -1;

  tcsetpgrp(shell_tty, shell_pgrp);
  path_init(envp);

  return 0;
}

static void shell_cleanup(void) {
  tcsetpgrp(shell_tty, getpgrp());
  sh_write(STDOUT_FILENO, "Exiting...\n", 11);
  jobtable_cleanup(&tbl);
  sig_cleanup();
  close(shell_tty);
}

int main(int argc, char **argv, char **envp) {
  Job *job;
  char *buf;
  char *tokens[ARG_MAX + 1];
  size_t num_tokens;
  ssize_t num_bytes;
  int ret;

  (void)argc;

  if (shell_init(argv, envp) == -1)
    return 1;

  while (1) {
    if (sig_chld_pending) {
      sig_chld_pending = 0;
      jobtable_update(&tbl);
    }

    buf = (char *)xmalloc(BUF_SIZE);
    sh_write(STDOUT_FILENO, prompt, my_strlen(prompt));
    sh_write(STDOUT_FILENO, "$ ", 2);

    num_bytes = read(STDIN_FILENO, buf, BUF_SIZE);
    if (num_bytes == -1 && errno == EINTR) {
      xfree(BUF_SIZE);
      continue;
    }

    if (num_bytes <= 1) {
      xfree(BUF_SIZE);
      continue;
    }

    buf[num_bytes - 1] = '\0';
    num_tokens = tok_split(tokens, ARG_MAX + 1, buf, "|<>&");

    if (!num_tokens)
      continue;

    ret = run_builtin((const char **)tokens, &tbl);
    if (ret == -1)
      break;
    if (ret == 1)
      continue;

    if (parse_input((const char **)tokens, &job)) {
      if (job->background)
        buf[num_bytes - 2] = '\0';
      job->command = buf;
      jobtable_run(&tbl, job);
    }
  }

  shell_cleanup();
  return 0;
}
