#include "tok.h"

#include <ctype.h>

#include "str.h"

/*
 * tok_next - extract the next token from src.
 *
 * Skips leading whitespace, then collects either a run of delimiter
 * characters or a run of non-delimiter characters (but not both).
 *
 * Advances *idx past the consumed characters including leading whitespace.
 *
 * Returns a heap-allocated token, or NULL at end of input.
 */
char *tok_next(const char *src, int *idx, const char *delim) {
  const char *start, *end;
  int is_delim;

  if (!src)
    return NULL;

  start = src + *idx;
  while (*start && isspace((unsigned char)*start))
    start++;

  if (!*start)
    return NULL;

  end = start;
  is_delim = delim && char_in_str(*end, delim);

  while (*end && !isspace((unsigned char)*end)) {
    if (delim && is_delim != char_in_str(*end, delim))
      break;
    end++;
  }

  *idx = (int)(end - src);
  return my_strndup(start, (size_t)(end - start));
}

/*
 * tok_split - split src into an array of tokens.
 *
 * Fills toks[] with up to n-1 tokens, null-terminates the array.
 *
 * Returns the number of tokens extracted.
 */
size_t tok_split(char *toks[], size_t n, const char *src, const char *delim) {
  int sidx = 0;
  size_t tidx = 0;

  while (tidx < n - 1) {
    toks[tidx] = tok_next(src, &sidx, delim);
    if (!toks[tidx])
      break;
    tidx++;
  }

  toks[tidx] = NULL;
  return tidx;
}
