#ifndef ERROR_H
#define ERROR_H

#include <stdarg.h>

void sh_error(const char *msg, ...);
void sh_perror(const char *msg);

#endif
