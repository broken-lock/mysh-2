#ifndef SIG_H
#define SIG_H

#include <signal.h>

extern volatile sig_atomic_t sig_chld_pending;

int sig_init();
void sig_init_child();
void sig_cleanup();

#endif
