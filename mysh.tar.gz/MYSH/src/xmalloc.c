#include "xmalloc.h"

#include <unistd.h>

/*
 * Simple arena allocator - allocates from a static heap buffer.
 * xfree_all() resets the entire arena. xfree() reclaims
 * the most recent allocation only.
 */

#define HEAP_SIZE (1024 * 1024)
#define ALIGN8(n) (((n) + 7) & ~(size_t)7)

static char heap[HEAP_SIZE];
static char *free_ptr = heap;

/*
 * Bump-allocate size bytes from the arena.
 *
 * Guaranteed memory allocation or terminate the calling process.
 */
void *xmalloc(size_t size) {
  char *request;

  size = ALIGN8(size);
  request = free_ptr;
  free_ptr += size;

  if (free_ptr > heap + HEAP_SIZE) {
    write(STDERR_FILENO, "out of memory\n", 14);
    _exit(1);
  }

  return request;
}

void xfree(size_t size) {
  size = ALIGN8(size);
  if ((free_ptr - heap) >= (ssize_t)size)
    free_ptr -= size;
}

void xfree_all(void) {
  free_ptr = heap;
}
