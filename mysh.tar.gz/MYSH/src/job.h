#ifndef JOB_H
#define JOB_H

#include <stddef.h>     /* size_t */
#include <sys/types.h>  /* pid_t */

#include "global.h"     /* ARG_MAX, PIPELINE_MAX */

#define NO_PID (-1)
#define NO_FD  (-1)

typedef struct {
  char *argv[ARG_MAX + 1];
  size_t argc;
  pid_t pid;
  int status;
} Command;

typedef struct {
  char *command;
  pid_t pgid;
  Command *pipeline[PIPELINE_MAX];
  size_t num_stages;
  char *out_file;
  char *in_file;
  int background;
  int finished;
  int stopped;
} Job;

int job_run(Job *job);
int job_fg_wait(Job *job);
int job_fg_resume(Job *job);
int job_bg_resume(Job *job);
int job_resume(Job *job);
int job_update(Job *job, int opts);
void job_cleanup(Job *job, unsigned int secs);

#endif
