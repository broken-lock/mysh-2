#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "builtin.h"
#include "error.h"
#include "job.h"
#include "sh_util.h"
#include "sig.h"
#include "str.h"

static void builtin_help(void) {
  const char guide[] =
      "The following are internal commands defined for this shell\n"
      "help                         Show this guide\n"
      "exit                         Exit this shell\n"
      "jobs                         Show all background jobs\n"
      "fg [job_num]                 Foreground the most recent"
      " background job\n"
      "bg [job_num]                 Continue a background job\n"
      "cd [dir]                     Change working directory\n";

  sh_write(STDOUT_FILENO, guide, sizeof(guide) - 1);
}

/* Flush any pending SIGCHLD notifications before printing. */
static void builtin_jobs(JobTable *tbl) {
  if (sig_chld_pending) {
    sig_chld_pending = 0;
    jobtable_update(tbl);
  }
  jobtable_print_all(tbl);
}

/*
 * find_job - resolve a job argument to a table entry.
 *
 * Accepts three forms: no argument (most recent job),
 * %N (job number), or a raw pid (process group).
 * Sets *id to a display string for error messages.
 */
static JobEntry *find_job(const char *tokens[], JobTable *tbl,
                          const char **id) {
  int job_num;
  pid_t pgid;

  if (!tokens[1]) {
    *id = "current";
    job_num = tbl->num_jobs;
    pgid = -1;
  } else if (tokens[1][0] == '%') {
    *id = tokens[1][1] ? tokens[1] + 1 : "current";
    job_num = tokens[1][1] ? (int)strtol(*id, NULL, 10) : tbl->num_jobs;
    pgid = -1;
  } else {
    *id = tokens[1];
    job_num = -1;
    pgid = (pid_t)strtol(tokens[1], NULL, 10);
  }

  return jobtable_find(tbl, job_num, pgid);
}

/* Resume a job in the foreground, wait for it, then reclaim terminal. */
static void builtin_fg(const char *tokens[], JobTable *tbl) {
  const char *id;
  JobEntry *entry = find_job(tokens, tbl, &id);

  if (!entry) {
    sh_error("fg", id, "no such job", NULL);
    return;
  }

  if (job_fg_resume(entry->job) == -1) {
    sh_error("fg", id, "terminated", NULL);
    job_cleanup(entry->job, 2);
  }

  if (entry->job->finished) {
    jobtable_remove(tbl, entry);
  } else {
    jobtable_update_recent(tbl, entry);
    jobtable_print(entry);
  }
}

/*
  builtin_bg - run a job in the background, stopped jobs are resumed.
*/
static void builtin_bg(const char *tokens[], JobTable *tbl) {
  const char *id;
  JobEntry *entry = find_job(tokens, tbl, &id);

  if (!entry) {
    sh_error("bg", id, "no such job", NULL);
    return;
  }

  if (job_bg_resume(entry->job) == -1) {
    sh_error("bg", id, "terminated", NULL);
    job_cleanup(entry->job, 2);
  }
}

/*
  builtin_cd - change the working directory.
 */
static void builtin_cd(const char *tokens[]) {
  if (!tokens[1])
    sh_error("cd", "expected argument", NULL);
  else if (chdir(tokens[1]) == -1)
    sh_error("cd", tokens[1], strerror(errno), NULL);
}

/*
 * run_builtin - run a builtin command.
 *
 * Returns -1 to exit the shell, 1 if handled, 0 if not a builtin.
 */
int run_builtin(const char *tokens[], JobTable *tbl) {
  if (my_strcmp(tokens[0], "exit") == 0)
    return -1;

  if (my_strcmp(tokens[0], "help") == 0)
    builtin_help();
  else if (my_strcmp(tokens[0], "jobs") == 0)
    builtin_jobs(tbl);
  else if (my_strcmp(tokens[0], "fg") == 0)
    builtin_fg(tokens, tbl);
  else if (my_strcmp(tokens[0], "bg") == 0)
    builtin_bg(tokens, tbl);
  else if (my_strcmp(tokens[0], "cd") == 0)
    builtin_cd(tokens);
  else
    return 0;

  return 1;
}
