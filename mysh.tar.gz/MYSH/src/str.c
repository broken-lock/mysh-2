#include "str.h"

#include "xmalloc.h"

/*
 * append - copy src into *dst, advancing *dst and decrementing *rem.
 *
 * Returns 1 if the full string was copied, 0 if truncated.
 * Always null-terminates if *rem > 0.
 */
int append(char **dst, const char *src, size_t *rem) {
  char *p = *dst;

  if (!*rem)
    return 0;

  while (*rem > 1 && *src) {
    *p++ = *src++;
    (*rem)--;
  }

  *p = '\0';
  *dst = p;

  return (*src == '\0');
}

size_t my_strlen(const char *s) {
  size_t i = 0;

  while (s[i])
    i++;

  return i;
}

int my_strcmp(const char *s1, const char *s2) {
  while (*s1 && *s1 == *s2) {
    s1++;
    s2++;
  }

  return (unsigned char)*s1 - (unsigned char)*s2;
}

int my_strncmp(const char *s1, const char *s2, size_t n) {
  if (!n)
    return 0;

  while (--n && *s1 && *s1 == *s2) {
    s1++;
    s2++;
  }

  return (unsigned char)*s1 - (unsigned char)*s2;
}

char *my_strndup(const char *src, size_t n) {
  size_t len = 0, rem;
  char *dst, *p;

  while (len < n && src[len])
    len++;

  rem = len + 1;
  dst = (char *)xmalloc(rem);

  p = dst;
  append(&p, src, &rem);

  return dst;
}

const char *my_strchr(const char *s, char c) {
  while (*s && *s != c)
    s++;

  return *s ? s : NULL;
}

void my_memset(void *dst, unsigned char val, size_t n) {
  unsigned char *p = (unsigned char *)dst;

  while (n--)
    *p++ = val;
}

/*
 * num_to_str - convert integer to decimal string.
 *
 * Returns a pointer to a static buffer. Not reentrant.
 */
char *num_to_str(int num) {
  static char buf[16];
  char *p = buf + sizeof(buf) - 1;
  int neg = 0;

  *p = '\0';

  if (num < 0) {
    neg = 1;
    num = -num;
  }

  do {
    *--p = (char)('0' + (num % 10));
    num /= 10;
  } while (num);

  if (neg)
    *--p = '-';

  return p;
}

int char_in_str(char c, const char *s) {
  while (*s) {
    if (*s++ == c)
      return 1;
  }

  return 0;
}

int str_in_set(char *str, const char *set[]) {
  while (*set) {
    if (my_strcmp(str, *set++) == 0)
      return 1;
  }

  return 0;
}
