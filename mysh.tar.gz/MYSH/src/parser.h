#ifndef PARSER_H
#define PARSER_H

#include "job.h"

int parse_input(const char *tokens[], Job **j);

#endif
