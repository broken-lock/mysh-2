#include "parser.h"

#include "error.h"
#include "str.h"
#include "xmalloc.h"

typedef enum {
  PARSE_OK = 0,
  CMD_LIM_ERR,
  PIPE_LIM_ERR,
  TOKEN_ERR,
} ParseError;

typedef struct {
  ParseError code;
  const char *expected;
  const char *found;
} ParseErrInfo;

typedef struct {
  const char **curr;
  ParseErrInfo err_info;
} Parser;

static const char *op_terms[] = {"|", "<", ">", "&", NULL};

static inline const char *p_peek(const Parser *p) {
  return *(p->curr);
}

static inline void p_advance(Parser *p) {
  if (p_peek(p))
    p->curr++;
}

static inline int p_accept(Parser *p, const char *s) {
  const char *tok = p_peek(p);
  if (tok && my_strcmp(tok, s) == 0) {
    p_advance(p);
    return 1;
  }
  return 0;
}

static inline int p_is_word(const char *s) {
  return s && !str_in_set((char *)s, op_terms);
}

static inline void p_error(Parser *p, ParseError code, const char *expected,
                           const char *found) {
  p->err_info.code = code;
  p->err_info.expected = expected;
  p->err_info.found = found ? found : "newline";
}

static void p_print_error(const Parser *p) {
  switch (p->err_info.code) {
    case CMD_LIM_ERR:
      sh_error("syntax error command exceeded ARG_MAX", NULL);
      break;
    case PIPE_LIM_ERR:
      sh_error("syntax error job stages exceeded PIPELINE_MAX", NULL);
      break;
    case TOKEN_ERR:
      sh_error("syntax error near unexpected token", p->err_info.found, NULL);
      break;
    case PARSE_OK:
    default:
      break;
  }
}

/*
 * parse_command - collect consecutive words into a Command.
 */
static int parse_command(Parser *p, Command **cmd) {
  Command *c;

  if (!p_is_word(p_peek(p))) {
    p_error(p, TOKEN_ERR, "command", p_peek(p));
    return 0;
  }

  c = xmalloc(sizeof(*c));
  my_memset(c, 0, sizeof(*c));

  while (p_is_word(p_peek(p))) {
    if (c->argc >= ARG_MAX) {
      p_error(p, CMD_LIM_ERR, NULL, NULL);
      return 0;
    }
    c->argv[c->argc++] = (char *)p_peek(p);
    p_advance(p);
  }

  c->argv[c->argc] = NULL;
  *cmd = c;
  return 1;
}

/*
 * parse_pipeline - parse pipe-separated commands into pipeline array.
 */
static int parse_pipeline(Parser *p, Command *pipev[], size_t *n_stages) {
  size_t stage = 0;

  if (stage >= PIPELINE_MAX) {
    p_error(p, PIPE_LIM_ERR, NULL, NULL);
    return 0;
  }

  if (!parse_command(p, &pipev[stage]))
    return 0;
  stage++;

  while (p_accept(p, "|")) {
    if (!p_peek(p)) {
      p_error(p, TOKEN_ERR, "command", NULL);
      return 0;
    }
    if (stage >= PIPELINE_MAX) {
      p_error(p, PIPE_LIM_ERR, NULL, NULL);
      return 0;
    }
    if (!parse_command(p, &pipev[stage]))
      return 0;
    stage++;
  }

  *n_stages = stage;
  return 1;
}

/*
 * parse_job - parse a full job: pipeline, redirections, and background flag.
 */
static int parse_job(Parser *p, Job **job) {
  Job *j = xmalloc(sizeof(*j));
  my_memset(j, 0, sizeof(*j));

  if (!parse_pipeline(p, j->pipeline, &j->num_stages))
    return 0;

  if (p_accept(p, "<")) {
    if (p_is_word(p_peek(p))) {
      j->in_file = (char *)p_peek(p);
      p_advance(p);
    } else {
      p_error(p, TOKEN_ERR, "filename", p_peek(p));
      return 0;
    }
  }

  if (p_accept(p, ">")) {
    if (p_is_word(p_peek(p))) {
      j->out_file = (char *)p_peek(p);
      p_advance(p);
    } else {
      p_error(p, TOKEN_ERR, "filename", p_peek(p));
      return 0;
    }
  }

  if (p_accept(p, "&"))
    j->background = 1;

  if (p_peek(p)) {
    p_error(p, TOKEN_ERR, "end-of-line", p_peek(p));
    return 0;
  }

  *job = j;
  return 1;
}

/*
 * parse_input - entry point: parse token array into a Job.
 */
int parse_input(const char *tokens[], Job **j) {
  Parser p;
  p.curr = tokens;
  p.err_info.code = PARSE_OK;
  p.err_info.expected = NULL;
  p.err_info.found = NULL;

  if (parse_job(&p, j))
    return 1;

  p_print_error(&p);
  return 0;
}
