#ifndef JOBTBL_H
#define JOBTBL_H

#include "job.h"

typedef struct JobEntry {
  int job_id;
  Job *job;
  struct JobEntry *next;
  struct JobEntry *prev;
  struct JobEntry *recent_next;
  struct JobEntry *recent_prev;
} JobEntry;

typedef struct {
  JobEntry *head;
  JobEntry *tail;
  JobEntry *recent_head;
  JobEntry *recent_tail;
  int num_jobs;
} JobTable;

void jobtable_update_recent(JobTable *tbl, JobEntry *e);
JobEntry *jobtable_find(JobTable *tbl, int id, pid_t pgid);
void jobtable_remove(JobTable *tbl, JobEntry *e);
void jobtable_print(JobEntry *e);
void jobtable_print_all(JobTable *tbl);
void jobtable_update(JobTable *tbl);
int jobtable_run(JobTable *tbl, Job *job);
void jobtable_cleanup(JobTable *tbl);

#endif
