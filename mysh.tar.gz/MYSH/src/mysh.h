#ifndef MYSH_H
#define MYSH_H

#include "global.h"

/* command related constants */
#define NAME_MAX     255
#define ARG_MAX      255
#define PIPELINE_MAX 10
#define JOB_MAX      100

#define NOBLOCK (WNOHANG | WUNTRACED | WCONTINUED)
#define BLOCK   (WUNTRACED | WCONTINUED)

#define PIPE_READ_END  0
#define PIPE_WRITE_END 1

extern char *PATH[];

#endif
