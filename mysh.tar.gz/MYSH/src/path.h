#ifndef PATH_H
#define PATH_H

extern const char *shell_dirs;

void path_init(char *envp[]);
char *path_next(const char *dirs, int *idx);
const char *path_name_extract(const char *path);
char *path_join(const char *dir, const char *name);
char *path_resolve(const char *name, const char *dirs);
int path_error(const char *name);

#endif
