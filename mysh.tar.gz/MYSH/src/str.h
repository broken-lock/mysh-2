#ifndef STR_H
#define STR_H

#include <stddef.h>

/*
 * String functions — reimplementations of standard libc routines.
 */
size_t my_strlen(const char *s);
int my_strcmp(const char *s1, const char *s2);
int my_strncmp(const char *s1, const char *s2, size_t n);
char *my_strndup(const char *src, size_t n);
const char *my_strchr(const char *s, char c);
void my_memset(void *dst, unsigned char val, size_t n);
char *num_to_str(int num);

/* buffer building */
int append(char **dst, const char *src, size_t *rem);

/* search helpers */
int char_in_str(char c, const char *s);
int str_in_set(char *str, const char *set[]);

#endif
