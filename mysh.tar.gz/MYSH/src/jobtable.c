#include "jobtable.h"

#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

#include "sh_util.h"
#include "str.h"
#include "xmalloc.h"

/*
 * append_pad - append str and pad with spaces to width.
 */
static void append_pad(char **dst, const char *str, size_t *rem, size_t width) {
  size_t before = *rem;

  append(dst, str, rem);

  size_t written = before - *rem;
  while (written < width && *rem > 1) {
    *(*dst)++ = ' ';
    (*rem)--;
    written++;
  }
}

/*
 * fmt_id - format job id as "[N]" with +/- MRU indicator.
 */
static const char *fmt_id(JobEntry *e) {
  static char buf[16];
  char *p = buf;
  size_t rem = sizeof(buf);

  append(&p, "[", &rem);
  append(&p, num_to_str(e->job_id), &rem);
  append(&p, "]", &rem);

  if (!e->recent_prev)
    append(&p, "+", &rem);
  else if (!e->recent_prev->recent_prev)
    append(&p, "-", &rem);

  *p = '\0';
  return buf;
}

/*
 * fmt_status - format job state as "Running", "Stopped", "Done(N)", or signal
 * name.
 */
static const char *fmt_status(Job *job) {
  static char buf[32];
  char *p = buf;
  size_t rem = sizeof(buf);
  int code;
  int status = job->pipeline[job->num_stages - 1]->status;

  if (!job->finished)
    return job->stopped ? "Stopped" : "Running";

  if (WIFEXITED(status)) {
    append(&p, "Done", &rem);
    if ((code = WEXITSTATUS(status))) {
      append(&p, "(", &rem);
      append(&p, num_to_str(code), &rem);
      append(&p, ")", &rem);
    }
    *p = '\0';
    return buf;
  } else if (WIFSIGNALED(status)) {
    return strsignal(WTERMSIG(status));
  }

  return "Unknown";
}

/* MRU list operations. */
static void insert_recent(JobTable *tbl, JobEntry *e) {
  if (tbl->recent_head) {
    e->recent_next = tbl->recent_head;
    tbl->recent_head->recent_prev = e;
  } else {
    tbl->recent_tail = e;
  }
  tbl->recent_head = e;
}

static void remove_recent(JobTable *tbl, JobEntry *e) {
  JobEntry *next = e->recent_next;
  JobEntry *prev = e->recent_prev;

  if (next)
    next->recent_prev = prev;
  else
    tbl->recent_tail = prev;

  if (prev)
    prev->recent_next = next;
  else
    tbl->recent_head = next;
}

/* Main list operations. */
static void remove_entry(JobTable *tbl, JobEntry *e) {
  JobEntry *next = e->next;
  JobEntry *prev = e->prev;

  if (next)
    next->prev = prev;
  else
    tbl->tail = prev;

  if (prev)
    prev->next = next;
  else
    tbl->head = next;
}

/*
 * insert_entry - allocate a new entry and link into both lists.
 */
static JobEntry *insert_entry(JobTable *tbl) {
  JobEntry *e = (JobEntry *)xmalloc(sizeof(JobEntry));

  if (e) {
    my_memset(e, 0, sizeof(JobEntry));

    if (tbl->tail) {
      e->prev = tbl->tail;
      tbl->tail->next = e;
    } else {
      tbl->head = e;
    }
    tbl->tail = e;

    insert_recent(tbl, e);
  }

  return e;
}

/*
 * add_entry - insert a job, assign an id, and print the notification.
 */
static JobEntry *add_entry(JobTable *tbl, Job *job) {
  JobEntry *e, *prev;
  char buf[BUF_SIZE];
  char *p = buf;
  size_t rem = sizeof(buf) - 1;

  if ((e = insert_entry(tbl))) {
    e->job = job;
    prev = tbl->tail->prev;
    e->job_id = prev ? prev->job_id + 1 : 1;
    tbl->num_jobs++;

    append(&p, "[", &rem);
    append(&p, num_to_str(e->job_id), &rem);
    append(&p, "]", &rem);
    append(&p, " ", &rem);
    append(&p, num_to_str(job->pgid), &rem);
    *p++ = '\n';
    sh_write(STDOUT_FILENO, buf, (size_t)(p - buf));
  }

  return e;
}

void jobtable_update_recent(JobTable *tbl, JobEntry *e) {
  remove_recent(tbl, e);
  insert_recent(tbl, e);
}

/*
 * jobtable_find - search from both ends by id or pgid.
 */
JobEntry *jobtable_find(JobTable *tbl, int id, pid_t pgid) {
  JobEntry *l = tbl->head;
  JobEntry *r = tbl->tail;

  while (l && r) {
    if ((id > 0 && l->job_id == id) || l->job->pgid == pgid)
      return l;
    if ((id > 0 && r->job_id == id) || r->job->pgid == pgid)
      return r;
    if (l == r || r->next == l)
      break;
    l = l->next;
    r = r->prev;
  }

  return NULL;
}

void jobtable_remove(JobTable *tbl, JobEntry *e) {
  remove_entry(tbl, e);
  remove_recent(tbl, e);
  tbl->num_jobs--;
}

void jobtable_print(JobEntry *e) {
  Job *job = e->job;
  char buf[BUF_SIZE];
  char *p = buf;
  size_t rem = sizeof(buf) - 1;

  append_pad(&p, fmt_id(e), &rem, 8);
  append_pad(&p, num_to_str(job->pgid), &rem, 8);
  append_pad(&p, fmt_status(job), &rem, 24);
  append(&p, job->command, &rem);

  *p++ = '\n';
  sh_write(STDOUT_FILENO, buf, (size_t)(p - buf));
}

void jobtable_print_all(JobTable *tbl) {
  JobEntry *e, *next;

  for (e = tbl->head; e; e = next) {
    next = e->next;
    jobtable_print(e);
    if (e->job->finished)
      jobtable_remove(tbl, e);
  }
}

/*
 * jobtable_update - poll all background jobs for status changes.
 */
void jobtable_update(JobTable *tbl) {
  JobEntry *e;
  Job *job;

  for (e = tbl->head; e; e = e->next) {
    job = e->job;
    if (job_update(job, WNOHANG | WUNTRACED | WCONTINUED) > 0)
      jobtable_print(e);
  }
}

/*
 * jobtable_run - launch a job; add to table if backgrounded or stopped.
 */
int jobtable_run(JobTable *tbl, Job *job) {
  if (job_run(job) == -1)
    return -1;

  if ((job->finished && WIFSIGNALED(job->pipeline[job->num_stages - 1]->status)) || job->stopped)
    sh_write(STDOUT_FILENO, "\n", 1);
  
  if (job->stopped || job->background)
    add_entry(tbl, job);

  return 0;
}

void jobtable_cleanup(JobTable *tbl) {
  JobEntry *e;

  for (e = tbl->head; e; e = e->next)
    job_cleanup(e->job, 2);
}
