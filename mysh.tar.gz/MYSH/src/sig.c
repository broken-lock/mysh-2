#include "sig.h"

#include <signal.h>
#include <unistd.h>

#include "error.h"

volatile sig_atomic_t sig_chld_pending;

static struct sigaction old_sigint;
static struct sigaction old_sigchld;

/*
 * Print a newline so the prompt reprints on a fresh line.
 * SA_RESTART is not set, so read() returns EINTR and the
 * main loop can redisplay the prompt.
 */
static void sigint_handler(int sig) {
  (void)sig;
  write(STDOUT_FILENO, "\n", 1);
}

/*
 * Flag pending status change for the main loop to collect.
 * SA_RESTART is set so background job deaths don't interrupt
 * the user's read() at the prompt.
 */
static void sigchld_handler(int sig) {
  (void)sig;
  sig_chld_pending = 1;
}

static void set_handler(int sig, void (*handler)(int), int flags) {
  struct sigaction sa;

  sigemptyset(&sa.sa_mask);
  sa.sa_flags = flags;
  sa.sa_handler = handler;
  sigaction(sig, &sa, NULL);
}

static int save_handler(int sig, void (*handler)(int), int flags,
                        struct sigaction *old) {
  struct sigaction sa;

  sigemptyset(&sa.sa_mask);
  sa.sa_flags = flags;
  sa.sa_handler = handler;
  return sigaction(sig, &sa, old);
}

/*
 * sig_init - configure signal handling for the interactive shell.
 *
 * Saves prior SIGINT and SIGCHLD dispositions so sig_cleanup
 * can restore them when the shell exits.
 */
int sig_init() {
  if (save_handler(SIGINT, sigint_handler, 0, &old_sigint) == -1) {
    sh_perror("sigaction");
    return -1;
  }

  save_handler(SIGCHLD, sigchld_handler, SA_RESTART, &old_sigchld);

  /* Shell must not be stopped or quit by job-control signals. */
  set_handler(SIGTSTP, SIG_IGN, 0);  /* ^Z  */
  set_handler(SIGTTIN, SIG_IGN, 0);  /* bg read from tty  */
  set_handler(SIGTTOU, SIG_IGN, 0);  /* bg write to tty   */
  set_handler(SIGQUIT, SIG_IGN, 0);  /* ^\  */

  return 0;
}

/* Reset all signals to default before exec. */
void sig_init_child() {
  set_handler(SIGINT, SIG_DFL, 0);
  set_handler(SIGQUIT, SIG_DFL, 0);
  set_handler(SIGTSTP, SIG_DFL, 0);
  set_handler(SIGTTIN, SIG_DFL, 0);
  set_handler(SIGTTOU, SIG_DFL, 0);
  set_handler(SIGCHLD, SIG_DFL, 0);
  set_handler(SIGPIPE, SIG_DFL, 0);
}

/* Restore signal dispositions to what they were before sig_init. */
void sig_cleanup() {
  sigaction(SIGINT, &old_sigint, NULL);
  sigaction(SIGCHLD, &old_sigchld, NULL);

  set_handler(SIGTSTP, SIG_DFL, 0);
  set_handler(SIGTTIN, SIG_DFL, 0);
  set_handler(SIGTTOU, SIG_DFL, 0);
  set_handler(SIGQUIT, SIG_DFL, 0);
}
