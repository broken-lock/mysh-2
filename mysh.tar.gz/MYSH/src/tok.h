#ifndef TOK_H
#define TOK_H

#include <stddef.h>

char *tok_next(const char *src, int *idx, const char *delim);
size_t tok_split(char *toks[], size_t n, const char *src, const char *delim);

#endif
