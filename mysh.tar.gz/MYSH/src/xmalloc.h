#ifndef XMALLOC_H
#define XMALLOC_H

#include <stddef.h>

void *xmalloc(size_t n);
void xfree(size_t n);
void xfree_all(void);

#endif
