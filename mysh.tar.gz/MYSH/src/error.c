#include "error.h"

#include <errno.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>

#include "global.h"
#include "sh_util.h"
#include "str.h"

extern const char *shell_name;

/*
 * print_error - format and write a colon-separated diagnostic to stderr.
 *
 * Output: "shell_name: msg: arg1: arg2: ...\n"
 */
static void print_error(const char *msg, va_list args) {
  char buf[BUF_SIZE];
  const char *s;
  char *p = buf;
  size_t rem = sizeof(buf) - 1;

  append(&p, shell_name, &rem);

  for (s = msg; rem > 2 && s; s = va_arg(args, const char *)) {
    append(&p, ": ", &rem);
    append(&p, s, &rem);
  }

  *p++ = '\n';
  sh_write(STDERR_FILENO, buf, (size_t)(p - buf));
}

void sh_error(const char *msg, ...) {
  va_list args;

  va_start(args, msg);
  print_error(msg, args);
  va_end(args);
}

void sh_perror(const char *msg) {
  sh_error(msg, strerror(errno), NULL);
}
