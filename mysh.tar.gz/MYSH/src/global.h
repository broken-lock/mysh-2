#ifndef GLOBAL_H
#define GLOBAL_H

#define BUF_SIZE 1024
#define ARG_MAX 255
#define PIPELINE_MAX 16

#endif
