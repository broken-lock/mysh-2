#ifndef SH_UTIL_H
#define SH_UTIL_H

#include <sys/types.h> /* ssize_t */

ssize_t sh_read(int fd, char *buf, size_t count);
ssize_t sh_write(int fd, const char *buf, size_t count);

#endif
